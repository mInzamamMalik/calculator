﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        String op = "";
        double num1,num2,result;
        bool op_perfomed = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_Click(object sender, EventArgs e)
        {
            if (tbx.Text == "0" || (op_perfomed))
            {
                tbx.Clear();
            }
            op_perfomed = false;
            Button btn_1 = (Button)sender;
         
            if (btn_1.Text == ".") {
                if (!tbx.Text.Contains("."))
                    tbx.Text = tbx.Text + btn_1.Text;
            }else
            tbx.Text = tbx.Text + btn_1.Text;

        }

        private void Operator_Click(object sender, EventArgs e)
        {
            Button btn_1 = (Button)sender;
            if (num1 != 0)
            {
                btn_Equals.PerformClick();
                op = btn_1.Text;
                //formula.Text = 
                op_perfomed = true;
            }
            else
            {
                op = btn_1.Text;
                num1 = Double.Parse(tbx.Text);
                label1.Text = num1 + " " + op;
                op_perfomed = true;
            }
        }

        private void btn_Equals_Click(object sender, EventArgs e)
        {
           // op_perfomed = true;
            num2 = Double.Parse(tbx.Text);
            switch(op){
                case "+":
                    result =num1 +num2;
                    tbx.Text = result.ToString();
                    break;
                case "-":
                    result =num1 - num2;
                    tbx.Text = result.ToString();
                    break;
                case "*":
                    result =num1  * num2;
                    tbx.Text = result.ToString();
                    break;
                case "/":
                    result =num1 +num2;
                    tbx.Text = result.ToString();
                    break;
                case"%":
                    result = num1 % num2;
                    tbx.Text = result.ToString();
                    break;
                default:
                    break;
            
            }

            num1 = Double.Parse(tbx.Text);
           // formula.Text = "";
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            tbx.Text = "0";
        }

        private void btn_CE_Click(object sender, EventArgs e)
        {
            tbx.Clear(); 
        }

        private void btn_plus_min_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(tbx.Text);
            tbx.Text = (num1 * (-1)).ToString();
        }

        private void btn__1x_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(tbx.Text);
            tbx.Text = (1 / num1).ToString();
        }

        private void btn_sqrt_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(tbx.Text);
            tbx.Text = Math.Sqrt(num1).ToString();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            int lenght;
            String a = tbx.Text;
            lenght = a.Length;
            if (lenght >= 1) {

                a = a.Substring(0, lenght - 1);
                tbx.Text = a;
            }
        }

       
    }
}
